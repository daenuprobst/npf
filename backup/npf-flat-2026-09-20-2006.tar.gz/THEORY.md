# What is proved, what is only measured

The claim of this project is that the Petri net is *load-bearing*: every guarantee below follows from a piece of
Petri net structure, and for each one there is (a) a proof, (b) an argument or counterexample showing that the
generic counterpart (message passing with a free readout, as in PGNN) cannot have the property, and (c) a numerical
check or an ablation with identical capacity. Where a Petri component turned out *not* to carry weight, this is said.

Notation. Net `N = (P, T, Pre, Pos)`, incidence matrix `C = Pos − Pre ∈ ℝ^{P×T}`, marking `m ∈ ℝ^P_{≥0}`, firing
vector `σ ∈ ℝ^T_{≥0}`, state equation `m' = m + Cσ`. P-invariants: `ker Cᵀ`. T-invariants: `ker C`. `•t`, `t•`: input
and output places of `t`.

---

## P1  Conservation ⇔ state-equation form

**Proposition.** Let `m ↦ m + F(m)` be any update of the marking. Then `xᵀ(m + F(m)) = xᵀm` for every marking and
every P-invariant `x` **iff** `F(m) ∈ im C` for every `m`, i.e. iff `F = C·v` for some `v: ℝ^P → ℝ^T`.

*Proof.* (⇐) `xᵀCv = 0`. (⇒) `F(m) ⊥ ker Cᵀ` and `(ker Cᵀ)^⊥ = im C`. ∎

So an architecture conserves the invariants of the net for all weights exactly when its update *is* a firing. This
is not a design option among others. *Generic counterpart:* PGNN's update `h_p ← Φ(h_p, m_p)`, read out per place, is
conservative only on a measure-zero set of weights (single transition `p→q`, `x = (1,1)`: a readout bias `b` gives
`xᵀΔm = 2b`). *Measured:* relative drift of the invariants after 40 steps: NPF 1e-7 (float32 rounding), PGNN 1e-2,
and 1e5-1e8 under distribution shift (`results/REPORT.md`, task `next`).

## P2  Non-negative markings; enabling is forced

**Proposition (token-game layer).** Let `d ≥ 0` be arbitrary demands, `D_p = Σ_t Pre(p,t) d_t`,
`φ(x) = (1 − e^{−x})/x`, and `v_t = d_t · min_{p∈•t} φ(D_p / m_p)`. Then `m + Cv ≥ 0` for every `m ≥ 0`, and places
with `m_p > 0` stay positive.

*Proof.* For `p ∈ •t`, `v_t ≤ d_t φ(D_p/m_p)`, so the consumption at `p` is at most
`φ(D_p/m_p) D_p = m_p (1 − e^{−D_p/m_p}) < m_p`; production is non-negative; `φ(∞) = 0` covers `m_p = 0`. ∎

**Proposition (necessity of enabling).** Let the rate functions be *local* (`v_t` depends on `•t` only), *shared
across nets*, continuous and non-negative. If on every pure net and from every non-negative marking `ṁ = Cv(m)` has
a solution that stays in the non-negative orthant on some interval `[0, ε)`, then `v_t(m) = 0` whenever some input
place of `t` is empty.

*Proof.* In the net that consists of `t` and its places only, an input place `p` has no producer, so along a
solution from a marking with `m_p = 0` we have `0 ≤ m_p(τ) = −Pre(p,t) ∫₀^τ v_t ds`. As `v_t ≥ 0`, the integrand
vanishes almost everywhere, and by continuity everywhere, in particular at the start; by locality and sharing the
same function is used in every net. The quantifier over nets is essential: on a single net a source that refills
`p` faster than `t` drains it keeps the orthant invariant although `t` fires from an empty place. ∎

*Generic counterpart:* a free readout produces negative markings (measured: 4-9 % of all predicted markings for
PGNN/GNN in task `next`, 0 for NPF). *Check:* `npf/theory_checks.py` D, and the 200-step test with random weights.

## P3  The state-equation projection never hurts, and message passing cannot replace it

Two observed states give `ΔM = M_B − M_A`; the true firing vector `σ*` lies in `S = {σ : Cσ = ΔM}`.

**Proposition.** For any estimate `σ̃`, the projection `Π_S σ̃ = σ̃ + C⁺(ΔM − Cσ̃)` satisfies
`Π_S σ̃ − σ* = (I − C⁺C)(σ̃ − σ*)`: the error component in `im Cᵀ` vanishes and
`‖Π_S σ̃ − σ*‖ ≤ ‖σ̃ − σ*‖`, with equality iff `σ̃` already satisfies the state equation. Alternating with the
orthant `σ ≥ 0` keeps this monotonicity (Fejér), because `σ*` lies in both sets. With weights `W = diag(w) > 0`,
`σ̃ + W Cᵀ(C W Cᵀ)⁺(ΔM − Cσ̃)` is the orthogonal projection in the `W⁻¹` inner product and equals the posterior mean
of `σ ~ N(σ̃, W)` given the exact observation `Cσ = ΔM` (with observation noise `R`: the Kalman update,
`(C W Cᵀ + R)⁻¹`).

*Proof.* `C⁺C` is the orthogonal projector onto `im Cᵀ` and `C σ* = ΔM`; Pythagoras. The weighted case is the same
statement after the change of variables `σ ↦ W^{-1/2}σ`. ∎

Hence learning only has to resolve the T-invariant component (`ker C`); the rest is fixed by the data.

**Proposition (locality lower bound).** On the path net `p_0 → t_1 → p_1 → … → t_L → p_L` (no T-invariants) the
firing vector is `σ_k = −Σ_{j<k} ΔM_j`. Any estimator whose output at `t_k` depends only on the part of the net
within distance `K` of `t_k` errs by at least `δ/2` on one of two inputs that differ by `δ` at `p_0` (compensated at
`p_L`) whenever `k > K`: the two inputs coincide on the `K`-neighbourhood of `t_k` but have `σ_k` differing by `δ`. ∎

So no message-passing network with a fixed number of rounds is exact on nets larger than its receptive field, while
the projection is exact on every net. *Measured:* error in `im Cᵀ`: 0 for NPF, 0.27 RMSE for PGNN (multi-body
regime); "prediction takes A to B": 99.8 % vs 58 %; the ablation PGNN+SE (same trunk, projection on top) isolates the
effect. Chain experiment: `npf/locality.py`.

## P4  Sinkhorn is the equilibrium of the assignment net

Places `Z_ij` ("product atom i sits on precursor atom j"), transitions = partner swaps
`Z_ij + Z_kl ⇌ Z_il + Z_kj`. The P-invariants are the row sums and the column sums (`dim ker Cᵀ = n_r + n_c − 1`).

**Proposition.** With detailed-balanced kinetics and place energies `−S_ij`, the unique equilibrium in the
compatibility class fixed by the marginals is `z*_ij = exp(S_ij + α_i + β_j)`, i.e. the Sinkhorn scaling of `exp(S)`.

*Proof.* By P8 (iii) the equilibrium potential `log z − S` lies in `ker Cᵀ = {α_i + β_j}`; uniqueness follows from
strict convexity of the free energy on the transportation polytope. ∎  *Check:* `theory_checks.py` C (2e-15).
*Ablation:* replacing the equilibrium by a row-softmax is the PGNN-style mapper (90.6 % vs 93.1 %); see the
component ablations in `results/REPORT.md`.

## P5  The state-equation readout is local, and invariant to everything it cannot see

Let the readout `ψ` of a place depend on its attributed `R`-ball only (here `R = K` for atom places and `K + 1` for
bond places, `K` = message-passing rounds), and let `π` map product atoms to precursor atoms.

**Proposition.** `r = Σ_B ψ − Σ_A ψ = Σ_{i ∈ Δ_R} [ψ_B(i) − ψ_A(π(i))] − Σ_{j ∉ π(B)} ψ_A(j)`, where `Δ_R` is the set of
atoms within `R` bonds of a place that a firing changes. Consequently (i) the attribution of every other atom is
exactly zero, and (ii) `r` is unchanged by any modification applied consistently to both sides at distance `> 2R`
from every changed place.

*Proof.* If the `R`-balls of `i` and `π(i)` are isomorphic as attributed graphs, a deterministic local function gives
`ψ_B(i) = ψ_A(π(i))` and the pair cancels. A consistent modification at distance `> 2R` alters only balls that contain
no changed place; those terms still cancel pairwise, and the terms in `Δ_R` are untouched. ∎

*Generic counterpart:* pooling the two sides separately has neither property. *Measured* (`npf/chem_invariance.py`,
4,000 counterfactuals: a methyl group attached ≥ 9 bonds from everything that changes): logits of the state-equation
readout move by 6e-14 in double precision (9e-5 in float32) and no prediction changes; the generic readout moves
logits by up to 40 and changes 0.26 % of the predictions. The learned participation gate of the full classifier is
*not* local and breaks exactness (0.065 % changes). *Honest note:* in-distribution accuracy of the two readouts is
the same; the Petri readout is load-bearing for invariance and attribution, not for accuracy on the standard split.

## P6  Every marking the token game reaches is valence-valid

The hydrogen place of atom `i` is determined by the per-atom P-invariant:
`h_i(M) = h_i(M_A) − Σ_j (order_M(ij) − order_A(ij))` (holds for 99.85 % of the product atoms of Schneider 50k).
A transition is enabled iff firing it keeps `h ≥ −capacity − ½` at both of its atoms.

**Proposition.** Every marking reached by a sequence of enabled firings satisfies `h_i ≥ −capacity_i − ½` for every
atom. *Proof.* Induction over the sequence; a firing changes `h` only at its two atoms, where enabling is checked. ∎

*Generic counterpart:* labelling all bond places in one shot has no invariant: 3.9 % of its predictions violate a
capacity. *Ablations* (`results/REPORT.md`): token game without enabling, one-shot with enabling masks, one-shot.

## P7  Probabilities belong to traces, not to sequences

The state equation is additive, so two firing sequences with the same Parikh vector reach the same marking:
`P(M) = Σ_{s enabled, Parikh(s) = σ} p(s)`. Beam search that merges sequences by Parikh vector therefore computes a
lower bound of `P(M)` that is exact when all enabled linearisations survive; merging further by product adds the
symmetry-equivalent traces. The training loss `−log Σ_{t remaining and enabled} p(t | M)` is the exact negative
log-likelihood of "the next firing belongs to the target trace". *Measured:* expected calibration error 0.10 for
sequence probabilities, 0.027 after merging.

## P8  Thermodynamic equilibrium layer  (implemented in `npf/thermo.py`)

Reversible net, energies `E_p`, `m_ref = e^{−E}`, free energy `F(m) = Σ_p m_p (log(m_p / m_ref,p) − 1)`,
potentials `μ = ∇F = log(m / m_ref)`, flux `v_t = κ_t(m) (e^{Pre_tᵀμ} − e^{Pos_tᵀμ})` with **any** `κ_t > 0`.

**Proposition.** (i) `xᵀm` is conserved for every P-invariant `x`. (ii) `dF/dt = −Σ_t κ_t (a_t − b_t)(e^{a_t} − e^{b_t}) ≤ 0`
with `a = Preᵀμ`, `b = Posᵀμ`: `F` is a Lyapunov function for every choice of the learned conductances. (iii) A
positive marking is an equilibrium iff `Cᵀμ = 0`, i.e. iff the potential is a P-invariant. (iv) Every positive
compatibility class `(m_0 + im C) ∩ ℝ^P_{>0}` contains exactly one equilibrium, the minimiser of `F` on the class,
`m* = m_ref ⊙ exp(Xλ)` with `X` a basis of `ker Cᵀ` and `λ` the solution of the smooth, strictly convex dual
`min_λ Σ_p m_ref,p e^{(Xλ)_p} − λᵀXᵀm_0` (Birch's theorem / Horn-Jackson). (v) `(m_0, E) ↦ m*` is smooth
(implicit function theorem, Hessian `Xᵀ diag(m*) X ≻ 0`), so the layer is differentiable.

*Proof.* (i) P1. (ii) `dF/dt = μᵀCv = Σ_t (b_t − a_t) κ_t (e^{a_t} − e^{b_t})` and `(a − b)(e^a − e^b) ≥ 0`.
(iii) `v = 0 ⇔ a_t = b_t ∀t ⇔ Cᵀμ = 0`. (iv) `F` is strictly convex and its gradient diverges at the boundary; the
KKT condition of `min F` on the class is `∇F ∈ (im C)^⊥ = ker Cᵀ`, which is (iii); strict convexity gives uniqueness.
(v) standard. ∎  *Check:* `theory_checks.py` A (Lyapunov 1e-15, potentials in `ker Cᵀ` 6e-16), B (softmax is the
equilibrium of a state-machine net), F (deficiency-zero net that is not detailed balanced).

*Generic counterpart:* the equilibrium depends on the conserved totals, which are global; by the argument of P3 a
fixed number of message-passing rounds cannot compute it on nets larger than the receptive field.

## P9  Coloured tokens: conservation dictates aggregation and gating  (implemented in `npf/coloured.py`)

Tokens carry a feature (colour); `c_p` is the mean colour on place `p`. A transition emits tokens of colour
`o_θ(c̄_t, a_t)` (a learned arc expression of the Pre-weighted mean input colour), its rate law gets a learned guard
on `c̄_t`, and the place update is **not** learned:

    c_p⁺ = ((m_p − out_p) c_p + Σ_t Pos(p,t) v_t o_t) / m_p⁺ ,     out_p = Σ_t Pre(p,t) v_t .

**Proposition.** For all weights: masses obey P1/P2; `c_p⁺` is a convex combination of `c_p` and the arriving
colours (weights `(m_p − out_p)/m_p⁺ ≥ 0` and `Pos v_t/m_p⁺ ≥ 0`, summing to one because `m_p⁺ = m_p − out_p + Σ Pos v_t`);
a place without inflow keeps its colour exactly. *Generic counterpart:* a learned update `c + f_θ(messages)` has
none of the three. *Ablation (same masses, free colour update)*: colour RMSE 0.116 vs 0.0136 one step ahead,
0.207 vs 0.038 after eight steps; PGNN+ with 16× the parameters: 0.032 / 0.072; colour change of places without
inflow 2e-7 vs 0.012–0.024.

## P10  Learned incidence: the state equation identifies arc weights; invariants are not continuous in them  (`npf/sheaf.py`)

Arc weights as functions of the attributes at the two ends of an arc, `Pos_θ(p,t) = exp ρ_θ(e_in(t), e_p)` (scalar
restriction maps of a cellular sheaf on the net). Two facts decide whether this can be trained:

1. With markings and firing counts in the training data, `m_B − m_A = C_θ σ*` is a *linear regression* for the arc
   weights. The consistency loss `‖m_B − m_A − C_θ σ*‖²` recovers the hidden conversion ratios to 0.00 % relative error;
   gradients through the projection alone do not (ratio error 63–126 %, RMSE 0.89 vs 0.39 for the oracle).
2. `ker C` and `ker Cᵀ` are **not continuous** in the arc weights: a cycle of conversions is a T-invariant only if its
   ratios multiply to exactly one. A learned `C_θ` that is off by 0.02 % has full column rank with singular values of
   order 1e-4, and `C_θ⁺` amplifies the residual by 1e4 (observed: RMSE 31). The numerical rank therefore has to be
   taken with a tolerance matched to the accuracy of the learned weights (`RANK_TOLERANCE = 1e-3`); with it the learned
   net reproduces the oracle (RMSE 0.388 vs 0.386; takes A to B 0.834 vs 0.826).

Accuracy in this regime (single-input single-output transitions) is at the noise floor for every model, PGNN included
(0.375–0.391): the extension buys the *readable conservation law* (the price vector), not accuracy.

## Where the statements live

The paper (`paper/sections/method.tex`, `chem.tex`, proofs in `appendix.tex`) is the canonical statement of
Propositions 1–7 and Corollary 1; `uv run python -m npf.paper_checks` checks each of them numerically, against the
implementation with untrained weights where possible.
