# Neural Petri Flow (NPF)

A neural network that *remains a Petri net*, evaluated against the Petri Graph Neural Network (PGNN) of
Ademovic Tahirovic et al., Sci. Rep. 15:17540 (2025) (`s41598-025-01856-9.pdf`).

PGNN uses the Petri net as wiring for message passing: the functions Ψ, AGG, Φ are free, so markings,
enabling, firing and the state equation are not part of the model. NPF turns that around. The **only learned
object is the local rate law** of a transition,

    λ_t(m) = exp( β_θ(a_t) + Σ_{p ∈ •t} g_θ(m_p, e_p, Pre(p,t)) ) · [t enabled]

(local to the input places, zero without tokens, product form = generalised mass action), and **everything
else is Petri net semantics with no parameters**:

| task | what NPF computes |
|---|---|
| next state | **Token game**: `m ← m + C·v`, demand = rate·dt. Conflict resolution at places (a place facing demand `D` hands out `m(1 − e^(−D/m))` tokens, shared in proportion to the demands), `min` synchronisation at transitions. Markings stay ≥ 0 and every P-invariant (`xᵀC = 0`) is conserved exactly, for any weights. |
| transitions between two states A, B | **Bridge + state equation.** (1) Path: play the token game from A, pin its end to B. (2) Prior: `σ̃ = Δt · mean_path λ_θ`, times a local posterior correction `exp(c_θ)` that may also look at the output places. (3) State equation `M_B = M_A + C·σ` imposed by a Poisson-weighted projection `σ̃ + W Cᵀ (C W Cᵀ)⁺ (ΔM − C σ̃)`: one solve with the Petri Laplacian. The data fix the component of σ in `im Cᵀ`; learning only has to resolve the T-invariant component (`ker C`). (4) Occupancy refinement: consumers of a place share it in proportion to their rates, so places whose consumers must fire more than predicted are rescaled and (2)-(3) repeated. With noisy states (3) becomes a Kalman update with a learned observation variance. |

## Layout

    npf/data.py            random attributed nets, stochastic token game (Gillespie), continuous flow, batching
    npf/models.py          NPF, PGNN (paper Eqs. 9-12), PGNN variants and ablations, GNN, linear PGNN (Eq. 13)
    npf/experiment.py      train + evaluate one (task, regime, model, seed)
    npf/sweep.py           run everything that has no result yet, in parallel
    npf/paper_protocol.py  the paper's own protocol: one fixed net, 100 samples, 70/30, 300 epochs
    npf/report.py          results/*.json -> markdown tables
    npf/chem_data.py       Schneider 50k / USPTO-MIT as pairs of attributed graphs, product reconstruction from markings
    npf/chem_models.py     valence-net encoder, TokenGame, Mapper, Classifier and their PGNN-style counterparts
    npf/chem_experiment.py train + evaluate the chemistry tasks; chem_ensemble.py, chem_rxnmapper.py, chem_insights.py
    npf/theory_checks.py   numerical checks of the underlying theory (Lyapunov function, invariants, softmax and
                           Sinkhorn as Petri net equilibria, ReLU from synchronisation, deficiency-zero theorem)
    npf/paper_checks.py    numerical checks of the propositions exactly as stated in the paper, against the implementation
    npf/locality.py        chain nets of growing length: message passing cannot replace the state-equation projection
    npf/thermo.py          equilibrium layer (learned place energies, dual Newton, implicit differentiation) + baselines
    npf/sheaf.py           learned incidence (hidden conversion ratios); npf/coloured.py: coloured tokens
    npf/chem_invariance.py counterfactual invariance of the classifier; npf/chem_review.py: blinded mapping review package
    npf/paper_tables.py    results/REPORT.md -> paper/tables/appendix_tables.tex
    paper/                 ICLR-style draft (main.tex, sections/, figures/, references.bib)

## Reproduce

    uv sync
    uv run python -m npf.sweep --task transitions      # main task
    uv run python -m npf.sweep --task next --iters 3000
    uv run python -m npf.paper_protocol
    uv run python -m npf.report > results/REPORT.md

## Data

Dynamic graphs are random Petri nets with node attributes: places carry a marking (dynamic) and `e_p`
(static), transitions carry `a_t` (static). `graph` regimes use ordinary directed graphs (every transition is
an edge u → v), `petri` regimes use multi-body transitions with arc weights 1-2; half of the transitions
are reversible, so nets have T-invariants. Training nets have 6-12 places. Test splits: unseen nets of the
same size, 2-3× larger nets, 3× more tokens, and longer gaps between the two states.

* **transitions** (main): run the stochastic token game (stochastic mass action, hidden from the models),
  sample two states A and B, predict how often every transition fired in between. `petri-ode` is the same
  task on deterministic continuous flow, i.e. without irreducible noise.
* **next**: continuous token flow with saturating (`sat`) or infinite-server (`min`) kinetics; predict the
  next state, then roll the model out for 40 steps.

## Chemistry: reactions as firings of a valence Petri net

`npf/chem_*.py` evaluates the same idea on the Schneider 50k reactions (and USPTO-MIT for forward prediction).
A reaction instance is a Petri net over the heavy atoms of the precursors:

| Petri net | chemistry |
|---|---|
| place `B_ij`, marking = bond order | electron pairs shared by atoms i and j |
| places `H_i`, `Q_i` | hydrogens and charge of atom i |
| transition `B_ij → type k` | break / form / re-type a bond; tokens move between `B_ij` and `H_i`, `H_j` |
| state equation `E_B = E_A + C·σ` | Dugundji-Ugi `B + R = E` |
| P-invariant `Σ_j b_ij + h_i − q_i` per atom | valence conservation: holds for 99.85 % of the product atoms, so hydrogens and charges are never predicted, they follow from the invariant (the recorded firing vector reproduces the recorded product in 99.1 % of the reactions) |
| enabling: markings stay ≥ −capacity | valence rule; capacities measured on the data: C 0, N/O 1, S/P 2 |
| firing sequence up to reordering of concurrent transitions (trace) | one product, many equivalent edit orders |

All three tasks are questions about the firing vector σ:

* **forward prediction** (`TokenGame`): learned rates for every transition and for STOP; fire one *enabled*
  transition, update the marking through the state equation, recompute the rates. Training is order-agnostic
  (from a random part of the true firing vector any remaining enabled transition is a correct next step); beam
  search adds up the probabilities of firing orders that reach the same marking. Products are valence-valid by
  construction and the unrecorded by-products (HCl, H2O, ...) come with the prediction.
* **atom mapping** (`Mapper`): the correspondence between the places of B and A under which σ is most probable.
  Rounds of (i) expected number of bonds kept under the current correspondence, with learned costs per bond type
  and per hydrogen / charge that has to move, (ii) a net-morphism check (an atom and its expected partner must
  agree; disagreement spreads along bond places), (iii) Sinkhorn = the equilibrium of the assignment net, whose
  P-invariants are "one partner per product atom, at most one per precursor atom"; elements are conserved by a mask.
  Uniform costs (classical minimum chemical distance, `token_descent`) *lower* the agreement with recorded
  mappings by 4 points: the costs have to be learned. The forward model is a mapper as well: places keep their
  identity while tokens move, so the most probable firing sequence from A that reaches B carries the mapping.
* **classification** (`Classifier`): read σ through the state equation, `Σ_B φ(place) − Σ_A φ(place)` over atom and
  bond places at every depth; places no transition touches cancel exactly, so no atom mapping is needed and the
  attribution is confined to the reaction centre by construction. A participation gate weighs spectator molecules.

`--model pgnn` is the PGNN-style counterpart in every task: the same message passing on the same net with a
generic readout (pooled embeddings / similarity matching / independent labelling of bond places).

    uv run python -m npf.chem_data                 # featurise data/schneider50k.tsv (from the rxnfp repository)
    uv run python -m npf.chem_data uspto-mit       # featurise data/uspto_mit (Jin et al. 2017)
    uv run python -m npf.chem_experiment --task forward --model npf
    uv run python -m npf.chem_experiment --task forward --model npf --dataset uspto_mit --epochs 20
    uv run python -m npf.chem_experiment --task map --model npf
    uv run python -m npf.chem_experiment --task classify --model npf --seed 0   # then: python -m npf.chem_ensemble
    uv run python -m npf.chem_rxnmapper            # RXNMapper scored with the same mapping metrics
    uv run python -m npf.chem_insights             # validity, by-products, calibration, firing order, attribution, data audit

Atoms are put in canonical order after the atom-map numbers are removed, so neither order nor features leak the
mapping. Mapping metrics are invariant under resonance and tautomerism on both sides (bonds formed and broken, up
to the symmetry of the bare skeleton). Forward prediction is scored at product level (canonical SMILES without
stereochemistry), because part of the recorded mappings - and hence of the recorded edits - is wrong.

## The PGNN baseline

The authors published no code, so `PGNN` in `npf/models.py` is a reimplementation from the paper, with every
ambiguity resolved in the baseline's favour:

* Eq. 9, `m_t = Ψ(h_•t, h_t•, w_•t,t, w_t•,t)`: sum-pooled set functions over input and output places with the
  arc weights, then an MLP that also sees the transition attributes (instead of the paper's ordered
  concatenation, which would not transfer between nets).
* Eq. 10: the signed, incidence-weighted sum `m_p = Σ_t C[p,t]·m_t` over all incident transitions, as in the
  algorithm of Fig. 3a, the embedding matrix of Fig. 3d and Eq. 13. `pgnn-eq10` is the literal reading (incoming
  transitions only). `pgnn+` replaces it by learned, role-specific messages in both directions.
* Eq. 11: residual MLP update. Eq. 12: for transition-level targets the flow is read from a final `m_t`, which
  the paper itself interprets as network flow.
* 4 rounds with untied weights, hidden width 64: 290-410k parameters (NPF: 9-39k). `pgnn@8` uses 8 rounds.
* `pgnn-linear` (paper protocol only) is the special case the paper actually trains (Eq. 13, Fig. 3e): per-net
  learnable flow rates ω and conversion weights Pre/Pos on the known incidence pattern, linear + ReLU.

All models receive identical inputs, including the arc weights and directions, and the same training budget.

## Is the Petri net load-bearing?  (2026-09-20)

Every Petri component was tested against a generic counterpart of equal capacity; propositions and proofs are in
`THEORY.md` and `paper/sections/appendix.tex`, numerical checks in `npf/paper_checks.py` (all pass, also against the
implementation with untrained weights). Full tables: `results/REPORT.md`.

| component | criterion | Petri | generic | verdict |
|---|---|---|---|---|
| firing form `m + C v` | drift of conserved totals, 40 steps | 3e-7 | 1.3e-2 | load-bearing (guarantee) |
| enabling | negative markings | 0 | 3.8 % | load-bearing (guarantee) |
| state-equation projection | takes A to B / RMSE on chain nets L = 3..48 | 99.8 % / 0.000 at every length | 58 % / 0.16 -> 0.44 | load-bearing |
| equilibrium layer (learned energies, dual Newton) | nRMSE / drift | 0.006 / 4e-8 (also larger nets, 3x tokens) | 0.17 / 8e-2 | load-bearing |
| coloured tokens, conservation-dictated mixing | colour RMSE 1 / 8 steps | 0.014 / 0.038 | free update 0.116 / 0.207, PGNN+ 0.032 / 0.072 | load-bearing |
| learned incidence | conversion ratios recovered / RMSE | 0.00 % error / 0.388 (oracle 0.386) | PGNN+ 0.375 | readable conservation law, no accuracy; needs the state-equation consistency loss and a rank tolerance (invariants are not continuous in arc weights) |
| token game (sequential firing) | product top-1 | 92.3 % (83.2 % with 2k reactions) | one-shot 75.0 % (60.6 %) | load-bearing |
| enabling mask inside the token game | top-1 / valence-valid | 92.3 % / 100 % | 92.4 % / 99.91 % without the mask | **not** load-bearing for accuracy (guarantee only), at every training-set size |
| mapper: equilibrium / bond cost / token cost / net morphism | agreement with record, one removed | 93.1 % | 92.8 / 92.8 / 93.0 / 91.8 %; all removed 90.6 % | small each, 2.5 points together |
| state-equation readout | predictions changed by a distant methyl | 0.000 % | 0.258 % | load-bearing (exact invariance) |
| state-equation readout | accuracy with 1000 / 250 labels | 91.9 / 53.0 % | 76.2 / 28.2 % | load-bearing (label efficiency) |
| state-equation readout | accuracy with all labels / larger molecules | 97.6 / 69.7 % | 97.7 / 72.4 % | **not** load-bearing |
| explicit firing vector (our mapper -> sigma -> classifier) | accuracy, all labels | 98.35 +- 0.12 % | 97.7 % | load-bearing; equals the classifier fed with recorded mappings (98.3 %) |

## Paper

`paper/` holds an ICLR-style draft (`cd paper && latexmk -pdf main.tex`; 9 pages of main text + appendix with proofs).
No number of the appendix is typed by hand: `uv run python -m npf.report > results/REPORT.md && uv run python -m npf.paper_tables`
regenerates `paper/tables/appendix_tables.tex`. Red `[...]` marks in the PDF are results that are still pending.

## Results at a glance

Full tables (mean ± std over seeds): `results/REPORT.md`, regenerate with `uv run python -m npf.report > results/REPORT.md`.

**Synthetic dynamic graphs (NPF vs the paper's PGNN, identical inputs and budget).** Transitions between two
sampled states, multi-body regime: RMSE 0.965 vs 1.014, MAE 0.41 vs 0.47, the predicted firing vector takes A to B
in 99.8 % vs 58 % of the cases, nRMSE at 3x tokens 0.54 vs 0.70 and at longer time gaps 0.37 vs 0.54, with 39k vs
293k parameters. On plain graphs (all transitions pairwise) every model sits on the same noise floor (0.78-0.79).
Next-state prediction: PGNN fits one step better on multi-body kinetics, NPF conserves every P-invariant to 1e-7
(PGNN: 1e-2, and it diverges under distribution shift), never produces a negative marking, and its hidden layer
correlates with the true firing vector at r = 0.97-1.00 without ever being supervised on it. The paper's own protocol
(one fixed net, 70 training samples): RMSE 0.55 (NPF), 0.71 (PGNN, Eqs. 9-12), 0.85 (linear PGNN, Eq. 13).

**Schneider 50k.**

| task | NPF (Petri semantics) | same encoder, generic readout (PGNN-style) | reference on the same data |
|---|---|---|---|
| forward prediction, product top-1 / 2 / 3 / 5 | 92.3 ± 0.2 / 95.1 / 96.4 / 97.5 % (2 seeds), 100 % valence-valid | 75.0 % top-1, 3.9 % valence violations | – |
| atom mapping, same firing vector as recorded | 93.1 ± 0.1 % (mapper, 2 seeds), 92.4 % (read off the forward token game), 94.1 % (both) | 90.6 % | RXNMapper 85.7 % (same reactions and metric; unsupervised) |
| classification, 10k / 40k split | 97.6 ± 0.15 %, ensemble of 5: 98.0 % | 97.7 % | DRFP 95.5 % reproduced (95.6 % published) |

Data efficiency of forward prediction (product top-1, greedy): with 2,000 / 8,000 / 36,876 training reactions the token
game reaches 83.2 / 88.4 / 92.4 %, one-shot labelling with the same encoder 60.6 / 70.7 / 75.0 % - the Petri
semantics with 2,000 reactions beats the generic readout trained on 18 times more.

Caveats that matter: part of the recorded atom mappings is wrong (2 % of the test reactions are contradicted by NPF
*and* RXNMapper; typical causes are reagents filed as non-reactants and incomplete precursor lists), so mapping
numbers are agreements with a noisy record and forward prediction is scored at product level; our mapper is
supervised on the conventions of this data set while RXNMapper is not; in classification the Petri readout does not
beat the generic one in accuracy - what it adds is exact locality of the attribution. Stereochemistry is ignored.

**USPTO-MIT** (forward prediction, the benchmark with published numbers; top-1): the small token game (1.6 M
parameters, 20 epochs) reaches 81.9 % on the full test set; published: WLDN 79.6, MEGAN 89.3, Molecular
Transformer 90.4, NERF 90.7, Chemformer / ReactionSink 91.3. A larger run is documented in `results/REPORT.md` when finished.

**Beyond accuracy** (`npf/chem_insights.py`): by-products that were never in the training targets (HBr / HCl / HF
for halo-arylations, H2O for reductive aminations, ...); calibrated product probabilities (ECE 0.027) because the
probabilities of all firing orders and symmetry-equivalent traces of a product add up; 99.9 % of all top-5 beam
candidates are valid molecules; bonds are broken before new ones form at saturated atoms (846 : 9) because
enabling demands it; attribution of the classifier is exactly zero beyond three bonds from the reaction centre for
99.6 % of the atoms; learned transition costs are readable (keeping a single bond 2.2, single<->double 1.3-1.9,
aromatic -> non-aromatic -0.4, moving a hydrogen 1.0, a charge 1.6); and a data audit: recorded mappings that move
up to 29 tokens where 3 suffice, and 0.9 % of recorded mappings that do not reproduce the recorded product.

